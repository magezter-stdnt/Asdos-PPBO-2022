package com.java.p8;

// Subclass (turunan dari class Abstract)
// access modifier Teacher adalah public
public class Teacher extends Person {

    public Teacher() {
        counter++;
        System.out.println("Object Teacher created, counter from Person = " + counter);
    }
    
    // isi dari method task() untuk class Teacher
    public void task() {
        System.out.println("  > Teaching all day long");
    }
}
package com.java.p8;

// access modifier Person adalah default
abstract class Person {
    static int counter = 0;
    private String name;
    private int age;
    protected abstract void task(); // abstract method

    // Set method
    public void setName(String name) {
        this.name = name;
    }
    public void setAge(int age) {
        this.age = age;
    }

    // Get method
    public String getName() {
        return name;
    }
    public int getAge() {
        return age;
    }
  }
  
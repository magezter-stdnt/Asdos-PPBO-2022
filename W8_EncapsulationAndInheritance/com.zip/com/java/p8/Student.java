package com.java.p8;

// Subclass (turunan dari class Abstract)
// access modifier Student adalah public
public class Student extends Person {
    private int entryYear;
    
    public Student() {
        counter++;
        System.out.println("Object Student created, counter from Person = " + counter);
    }

    // isi dari method task() untuk class Student
    public void task() {
        System.out.println("  > Studying all day long from " + getEntryYear() + " to " + getGraduationYear());
    }

    // Set method
    public void setEntryYear(int entryYear) {
        this.entryYear = entryYear;
    }

    // Get method
    // entry year
    public int getEntryYear() {
        return entryYear;
    }
    // graduation year
    public int getGraduationYear() {
        return entryYear + 4;
    }
}